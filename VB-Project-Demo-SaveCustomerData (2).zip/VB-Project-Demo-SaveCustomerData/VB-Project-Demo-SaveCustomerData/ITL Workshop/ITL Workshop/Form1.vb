﻿'John-Jeremy Williams
'ITL Workshop
'3/13/2025

Imports System.IO ' Needed for file operations

Public Class Form1



    Private Sub submitButton_Click(sender As Object, e As EventArgs) Handles submitButton.Click

        Dim customerName As String = txtName.Text.Trim()
        Dim email As String = txtEmail.Text.Trim()
        Dim phone As String = txtPhone.Text.Trim()
        Dim filePath As String = "customers.txt" ' File where data will be saved

        ' Basic validation
        If customerName = "" Or email = "" Or phone = "" Then
            MessageBox.Show("Please fill in all fields.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Format the customer information
        Dim customerData As String = "Name: " & customerName & vbCrLf &
                                     "Email: " & email & vbCrLf &
                                     "Phone: " & phone & vbCrLf &
                                     "---------------------------" & vbCrLf

        Try
            ' Append data to file (creates file if it doesn't exist)
            File.AppendAllText(filePath, customerData)

            ' Show success message
            MessageBox.Show("Customer information saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Clear input fields
            ClearFields()
        Catch ex As Exception
            MessageBox.Show("Error saving customer data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Clears all input fields
    Private Sub ClearFields()
        txtName.Clear()
        txtEmail.Clear()
        txtPhone.Clear()


    End Sub

End Class
